import React,{useState} from 'react'
import "./contact.css";
import { Link } from "react-router-dom";
const Contact = () => {
  
  return (
  <div>
         <div className="imagesize4">
         <nav>
            <ul id="nav-mobile" className="right hide-on-med-and-down">
              <li>
                <Link to="/">
                  <a>Home</a>
                </Link>
              </li>

              <li>
                <Link to="/about">
                  <a>About</a>
                </Link>
              </li>
              <li>
                <Link to="/interest">
                  <a>Interest</a>
                </Link>
              </li>
              <li>
                <Link to="/Project">
                  <a>Project</a>
                </Link>
              </li>
              <li>
                <Link to="/login">
                  <a>Login</a>
                </Link>
              </li>
              
            </ul>
            <header className="App-header">
              <h1 className="diff ">Area of Interest</h1>

              <h4>Interest/Home</h4>
              <h2>
                <span className="text_1">
                  <b>I am a Full Stack developer</b>
                </span>
                <span className="text_2">
                  <b>B.E.Computer Science Engineering</b>
                </span>
              </h2>
            </header>
          </nav>
          </div>
          <div className="oo">
          <form action="#" method="post">
  <h1>Contact Us</h1>
  <p>Please take a moment to get in touch, we will get back to you shortly.</p>

  <div class="column">
    <label for="the-name">Your Name</label>
    <input type="text" name="name" id="the-name"/>

    <label for="the-email">Email Address</label>
    <input type="email" name="email" id="the-email"/>

    <label for="the-phone">Phone Number</label>
    <input type="tel" name="phone" id="the-phone"/>

    <label for="the-reason">How can we help you?</label>
    <select name="reason" id="the-reason">
    <option value="">Choose one</option>
    <option value="web">I need web design services</option>
    <option value="video">I need you to produce a video</option>
    <option value="3d">I need 3D polygon things</option>
  </select>
  </div>
  <div class="column">
    <label for="the-message">Message</label>
    <textarea name="message" id="the-message"></textarea>
    <label>
    <input type="checkbox" name="newsletter" value="yes"/> Join our mailing list?
    </label>
    <input type="submit" value="Send Message"/>
  </div>
</form>
</div>
</div>
  )
}

export default Contact;