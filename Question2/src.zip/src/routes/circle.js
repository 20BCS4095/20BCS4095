import React from 'react';
import './circle.css';

export default ({color}) => <div class="circle" style={color}></div>;


