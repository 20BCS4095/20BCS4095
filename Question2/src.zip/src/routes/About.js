import React from "react";
import "./about.css";
import Images from "./im.jpeg";
import "materialize-css/dist/css/materialize.min.css";
import { Link } from "react-router-dom";
class About extends React.Component {
  render() {
    return (
      <div>
        <div className="image2">
          <nav>
            <ul id="nav-mobile" className="right hide-on-med-and-down">
              <li>
                <Link to="/">
                  <a>Home</a>
                </Link>
              </li>

              <li>
                <Link to="/Project">
                  <a>Project</a>
                </Link>
              </li>
              <li>
                <Link to="/Contact">
                  <a>Contact</a>
                </Link>
              </li>
              <li>
                <Link to="/interest">
                  <a>Interest</a>
                </Link>
              </li>
              <li>
                <Link to="/login">
                  <a>Login</a>
                </Link>
              </li>
             
            </ul>
            <header className="App-header">
              <h1 className="diff">Hi It's me Swetha</h1>

              <h4>About/Home</h4>
              <h2>
                <span className="text_1">
                  <b>I am a Full Stack developer</b>
                </span>
                <span className="text_2">
                  <b>B.E.Computer Science Engineering</b>
                </span>
              </h2>
            </header>
          </nav>
        </div>
        <section id="about">
        <div className="container mt-4 pt-4">
            <h1 className="text-center">About Me</h1>
            <div className="row mt-4">
                <div className="col-lg-4">
                    
                </div>

                <div className="col-lg-8">
                    <p>  Hello, I am Swetha . I am currently studying B.E. Computer
                  Science Engineering in M.kumarasamy college .I am purseing 4
                  th year .I have intresed in learning new thing that I don't
                  know about that. </p>
                    <div className="row mt-3">
                        
                        <div className="col-md-6">
                            <ul>
                                <li>Father's Name:S.Murugaraj</li>
                                <li>Age: 52</li>
                                <li>Occupation: Bussiness</li>

                            </ul>
                        </div>
                        <div className="col-md-6">
                            <ul>
                                <li>Mother's Name:M.Jayarani</li>
                                <li>Age: 41</li>
                                <li>Occupation: Bussiness</li>

                            </ul>
                        </div>
                    </div>
                    <div ClassName="row mt-3">
                        <p> I am completed Schooling in Cheran Matriculation Hr. Sec School in Vennaimalai, Karur.
                        <ul>
                                <li>Department:Computer Science</li>
                                <li>Marks in 12th:531</li>
                                <li>Percentage:88.5%</li>
                                <li>Marks in 10th:438</li>
                                <li>Percentage:87.6%</li>
                            </ul>
                        </p>
                    </div>
                </div>
                </div>
            </div>
            <div className="skill">
              <h1>My skill</h1>
              <li><h3>html</h3>
              <span className="bar"><span className="html"></span></span>
              </li>
              <li><h3>css</h3>
              <span className="bar"><span className="css"></span></span>
              </li>
              <li><h3>c</h3>
              <span className="bar"><span className="c"></span></span>
              </li>
              <li><h3>javascript</h3>
              <span className="bar"><span className="javascript"></span></span>
              </li>
            </div>
    </section>
    
    <section id="services">
        <div className="container">
            <h1 className="text-center">Knowledge</h1>
            <div className="row s12 m4">
                <div className="col s12 m4">
                    <div className="card servicesText">
                        <div className="card-body">
                            <i className="fas servicesIcon fa-clock">Website Development</i>
                           
                            <p className="card-text ">What does a website developer do?
Web developers create and maintain websites. They are also responsible for the site's technical aspects, such as its performance and capacity, which are measures of a website's speed and how much traffic the site can handle. In addition, web developers may create content for the site
                            </p>
                        </div>
                    </div>  
                </div>
                <div className="col s12 m4">
                    <div className="card servicesText">
                        <div className="card-body">
                            <i className="fas servicesIcon fa-layer-group">Graphica Design</i>
                           
                            <p className="card-text ">Graphic design is a craft where professionals create visual content to communicate messages. By applying visual hierarchy and page layout techniques, designers use typography and pictures to meet users' specific needs and focus on the logic of displaying elements in interactive designs, to optimize the user experience
                            </p>
                        </div>
                    </div>  
                </div>

                <div className="col s12 m4">
                    <div className="card servicesText">
                        <div className="card-body">
                            <i className="far servicesIcon fa-check-circle">Machine Learning</i>
                           
                            <p className="card-text ">Machine learning (ML) is a type of artificial intelligence (AI) that allows software applications to become more accurate at predicting outcomes without being explicitly programmed to do so. Machine learning algorithms use historical data as input to predict new output values.
                            </p>
                        </div>
                    </div>  
                </div>
            </div>

            <div className="row">
                <div className="col s12 m4">
                    <div className="card servicesText">
                        <div className="card-body">
                            <i className="fas servicesIcon fa-search">3D Environment</i>
                           
                            <p className="card-text mt-3">What is 3D environment modeling? 3D environment modeling is the generation of realistic environments for games, film, architectural renderings, and advertising using specialized computer software.
                            </p>
                        </div>
                    </div>  
                </div>

                <div className="col s12 m4">
                    <div className="card servicesText">
                        <div className="card-body">
                            <i className="fas servicesIcon fa-shield-alt">History </i>
                           
                            <p className="card-text mt-3">
History is the study of change over time, and it covers all aspects of human society. Political, social, economic, scientific, technological, medical, cultural, intellectual, religious and military developments are all part of history.
                                Some quick example text to build on the card title and make up the bulk of the card's content.
                            </p>
                        </div>
                    </div>  
                </div>

                <div className="col s12 m4">
                    <div className="card servicesText">
                        <div className="card-body">
                            <a><i className="fas servicesIcon fa-wrench">Programming</i></a>
                         
                            <p className="card-text mt-3">Programming is the process of creating a set of instructions that tell a computer how to perform a task. Programming can be done using a variety of computer programming languages, such as JavaScript, Python, and C++.
                            </p>
                        </div>
                    </div>  
                </div>
            </div>
        </div>
    </section>

      </div>
    );
  }
}

export default About;
