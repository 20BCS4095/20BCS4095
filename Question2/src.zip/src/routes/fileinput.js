import React,{useState} from 'react'
import { Link } from "react-router-dom";
const Fileinput = () => {
  const[img,setImg]=useState();
  const userFile=(e)=>{
   const[file]=e.target.files;
   setImg(URL.createObjectURL(file));
  }
  return (
    <div> <input type="file" onChange={userFile} />
     <img src={img} alt=""/>
     <Link to="/Project">Go to project</Link>
     </div>
  )
}

export default Fileinput;