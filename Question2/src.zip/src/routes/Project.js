import Image7 from "./about2.jpg";
import "materialize-css/dist/css/materialize.min.css";
import M from "materialize-css";
import Image1 from "./pro1.png";
import Image2 from "./pro2.jpg";
import Image3 from "./pro3.png";
import Image4 from "./pro4.png";
import Image5 from "./pro5.png";
import Image6 from "./pro6.png";
import "./project.css";
import React, { Component } from "react";
import { Link } from "react-router-dom";

export class Project extends Component {
  constructor(props) {
    super(props);
    this.state = {
      currentview: "",
    };
  }
  handle = () => {
    var elems = document.querySelector(".carousel");
    M.Carousel.init(elems).open();
  };
  calculator=()=>{
    window.location.href="/calculator";
  }
  traffic=()=>{
    window.location.href="/traffic";
  }
  login=()=>{
    window.location.href="/login";
  }
  portfolio=()=>{
    window.location.href="/";
  }
  render() {
    return (
      <div>
        <div className="imagesize2">
        <nav>
            <ul id="nav-mobile" className="right hide-on-med-and-down">
              <li>
                <Link to="/">
                  <a>Home</a>
                </Link>
              </li>

              <li>
                <Link to="/about">
                  <a>About</a>
                </Link>
              </li>
              <li>
                <Link to="/Contact">
                  <a>Contact</a>
                </Link>
              </li>
              <li>
                <Link to="/interest">
                  <a>Interest</a>
                </Link>
              </li>
              <li>
                <Link to="/login">
                  <a>Login</a>
                </Link>
              </li>
              
            </ul>
            <header className="App-header">
              <h1 className="diff ">In this we see about my projects</h1>

              <h4>Project/Home</h4>
              <h2>
                <span className="text_1">
                  <b>I am a Full Stack developer</b>
                </span>
                <span className="text_2">
                  <b>B.E.Computer Science Engineering</b>
                </span>
              </h2>
            </header>
          </nav>
        
       </div>
        

        <div className="carousel " onClick={() => this.handle()}>
          <a className="carousel-item" href="#one!">
            <img src={Image2} />
        
          </a>
          <a className="carousel-item" href="#two!">
            <img src={Image3} />
            <a  onClick={()=>this.portfolio()}>Portfolio</a>
          </a>
          <a className="carousel-item" href="#three!">
            <img src={Image4} />
            <a  onClick={()=>this.calculator()}>Calculator</a>
          </a>
          <a className="carousel-item" href="#one!">
            <img src={Image5} />
            <a  onClick={()=>this.traffic()}>Trffic Signal</a>
          </a>
          <a className="carousel-item" href="#one!">
            <img src={Image1} />
         
          </a>
          <a className="carousel-item" href="#one!">
            <img src={Image6} />
            <a  onClick={()=>this.login()}>Login and sgin in</a>
          </a>
      </div>
      <div className="row"> 
      <div className="col s2 m4">
        
      <div className="flip-card">
  <div className="flip-card-inner">
    <div className="flip-card-front">
    <h1>Portfolio</h1>
    <p>About my self in this project</p>
    <p>Language used - react js</p>
    <p>Platform - visual Studio code</p>
    <p>Duration - 1 week</p>
    <p>Not a tearm work</p>
    <p>Tranning of 2 months hard work</p>
    </div>
    <div className="flip-card-back">
 <h1>Portfolio</h1>
   <p>This project is about the portfolio . Portfolio means the introduction about me using the font end language like html, css ,javascript and react js.</p>
    </div>
  </div>
</div>
</div>
<div className="col s12 m4">
<div className="flip-card">
  <div className="flip-card-inner">
    <div className="flip-card-front">
    <center><h1>Toll pay</h1>
    <div>   </div>
    <p>Using OCR method - Optical Character Recognition</p>
    <p>Language used - Python</p>
    <p>Platform - Machine Learning</p>
    <div></div>
    <p>Duration - 3 months</p>
    <p>This is team work</p></center>
    </div>
    <div className="flip-card-back">
  <h1>Toll pay</h1>
   <p>This project is about the toll apy system that is recently increaing menthod to easy pay menthod which is done using the Optical character recognition.Using this we don't need to use the human time to handle this reduce human work. </p>
    </div>
  </div>
</div>
</div>
<div className="col s12 m4">
<div className="flip-card">
  <div className="flip-card-inner">
    <div className="flip-card-front">
    <h1>Travel Companion</h1>
    <p>Using - Javascript</p>
    <p>Platform - Web app</p>
    <p>Duration - 3 months</p>
    <p>This is team work</p>
    </div>
    <div className="flip-card-back">
      <h1>Travel Companion</h1> 
   <p>This project is about the travel Companion app is used to reduce human effect and money and time using this we can go to any place without the human help.</p>
    </div>
  </div>
</div>
</div>
</div>
<div className="row"> 
<div className="col s12 m4">
<div className="flip-card">
  <div className="flip-card-inner">
    <div className="flip-card-front">
    <h1>Login/Sgin</h1>
    <p>Using - react js</p>
    <p>Platform - visual Studio code</p>
    <p>Duration - 1 hours</p>
    <p>This is not a team work</p>
    </div>
    <div className="flip-card-back">
      <h1>Login/Sgin</h1> 
   <p>Now a day the website that we are using is all have a sign and login page and that is stored in the dataset for feather uses.Using that we can login the that website</p>
    </div>
  </div>
</div>
</div>

<div className="col s12 m4">
<div className="flip-card">
  <div className="flip-card-inner">
    <div className="flip-card-front">
    <center><h1>Traffic light</h1>
    <div>   </div>
    <p>Using method- timeout</p>
    <p>Language used - react js</p>
    <p>Platform - visual Studio code</p>
    <div></div>
    <p>Duration - 1 hours</p>
    <p>This is not a team work</p></center>
    </div>
    <div className="flip-card-back">
  <h1>Traffic light</h1>
   <p>This project is about the traffic signal to create awarness about the traffic light and it is help to children undrstand easly anf help in self driving cars.Using this we can train the machine to stop ,wait and go using the signal. </p>
    </div>
  </div>
</div>
</div>
<div className="col s12 m4">
<div className="flip-card">
  <div className="flip-card-inner">
    <div className="flip-card-front">
    <h1>Calculator</h1>
    <p>Using - react js</p>
    <p>Platform - Web app</p>
    <p>Duration - 1 hours</p>
    <p>This is not a team work</p>
    </div>
    <div className="flip-card-back">
      <h1>Calculator</h1> 
   <p>This project is about the calculation using web app which do all the mathematical calculation like addition, subtraction ,multiplication and division.And this reduce the human ekkect and the result is also correct.</p>
    </div>
  </div>
</div>
</div>
</div>
</div>
    );
  }
}
export default Project;

