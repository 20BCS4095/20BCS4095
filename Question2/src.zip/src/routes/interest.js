import React, { Component } from "react";
import "./interest.css";
import "materialize-css/dist/css/materialize.min.css";
import Imagei1 from "./interest1.png";
import Imagei2 from "./interest2.jpg";
import Imagei3 from "./interest3.png";
import Imagei4 from "./interest4.png";
import Imagei5 from "./interest5.png";
import Imagei6 from "./interest6.jpg";
import { Link } from "react-router-dom";
export class Interest extends Component {
  constructor(props) {
    super(props);
    this.state = {
      currentview: "",
    };
  }

  render() {
    return (
      <div>
        <div className="imagesize3">
        <nav>
            <ul id="nav-mobile" className="right hide-on-med-and-down">
              <li>
                <Link to="/">
                  <a>Home</a>
                </Link>
              </li>

              <li>
                <Link to="/about">
                  <a>About</a>
                </Link>
              </li>
              <li>
                <Link to="/Contact">
                  <a>Contact</a>
                </Link>
              </li>
              <li>
                <Link to="/Project">
                  <a>Project</a>
                </Link>
              </li>
              <li>
                <Link to="/login">
                  <a>Login</a>
                </Link>
              </li>
              
            </ul>
            <header className="App-header">
              <h1 className="diff ">Area of Interest</h1>

              <h4>Interest/Home</h4>
              <h2>
                <span className="text_1">
                  <b>I am a Full Stack developer</b>
                </span>
                <span className="text_2">
                  <b>B.E.Computer Science Engineering</b>
                </span>
              </h2>
            </header>
          </nav>
          </div>
        <div>
          <figure className="wave">
            <img src={Imagei1} alt="rajni"></img>
            <figcaption>
              <b>Full Stack</b>
            </figcaption>
          </figure>
          <figure className="wave">
            <img src={Imagei2} alt="chuck"></img>
            <figcaption>
              <b>Machine Learning</b>
            </figcaption>
          </figure>
          <figure className="wave">
            <img src={Imagei5} alt="chan"></img>
            <figcaption>
              <b>Graphic design</b>
            </figcaption>
          </figure>
          <figure className="wave">
            <img src={Imagei3} alt="chan"></img>
            <figcaption>
              <b>Hear music</b>
            </figcaption>
          </figure>
          <figure className="wave">
            <img src={Imagei4} alt="bean"></img>
            <figcaption>
              <b>Drawing</b>
            </figcaption>
          </figure>
          <figure className="wave">
            <img src={Imagei6} alt="chan"></img>
            <figcaption>
              <b>Travel </b>
            </figcaption>
          </figure>
        </div>
      </div>
    );
  }
}
export default Interest;
