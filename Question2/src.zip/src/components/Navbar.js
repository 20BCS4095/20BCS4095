import "./NavbarStyles.css";
import React from "react";
import M from "materialize-css";
import { Link } from "react-router-dom";
import "materialize-css/dist/css/materialize.min.css";
const Navbar = () => {
  return (
    <div>
      <div className="homeimage">
     <nav >
    
    <div className="nav-wrapper  black">
      <a className="brand-logo">Portfolio</a>
    
      <ul id="nav-mobile" className="right hide-on-med-and-down">
      
        <li><Link to="/"><a>Home</a></Link></li>
        <li><Link to="About"><a>About</a></Link></li>
        <li><Link to="/Project"><a>Project</a></Link></li>
        <li><Link to="/Contact"><a>Contact</a></Link></li>
        <li><Link to="/login"><a>Login</a></Link></li>
        <li>   <Link to="/interest"><a>Interest</a></Link></li>
       
      </ul>
    </div>
    <header className="App-header">
               <h1 className="diff">Hello,I am Swetha</h1>
            
          
            <h4>Welcome to my world</h4>
            <h2>
              <span className="text_1">
                <b>I am a Full Stack developer</b>
              </span>
              <span className="text_2">
                <b>B.E.Computer Science Engineering</b>
              </span>
            </h2>
          </header>
    
          <center>
            
            <a
              className="btn  "
              onClick={() =>
                M.toast({ html: "I have interested in full stack" })
              }
            >
              HIRE ME
            </a>
          </center>
  </nav>
  </div>
    </div>
  );
};
 
export default Navbar;
