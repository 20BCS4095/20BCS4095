import React from "react";
import "./index.css";
import Home from "./routes/Home";
import About from "./routes/About";
import Project from "./routes/Project";
import Contact from "./routes/Contact";
import Traffic from "./routes/traffic";
import {Route,Routes} from "react-router-dom"
import Fileinput from "./routes/fileinput";
import Calculator from "./routes/calculator";
import Login from "./routes/login";
import Interest from "./routes/interest";
function App() {
  return (
    <Routes>
    <Route path="/" element={<Home/>}/>
    <Route path="/project" element={<Project/>}/>
    <Route path="/about" element={<About/>}/>
    <Route path="/contact" element={<Contact/>}/>
    <Route path="/traffic" element={<Traffic/>}/>
    <Route path="/fileinput" element={<Fileinput/>}/>
    <Route path="/calculator" element={<Calculator/>}/>
    <Route path="/login" element={<Login/>}/>
    <Route path="/interest" element={<Interest/>}/>
  </Routes>
  );
}

export default App;
